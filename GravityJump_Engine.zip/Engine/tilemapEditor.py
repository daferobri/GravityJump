import tkinter as tk
from tkinter import filedialog, messagebox
import os

HAS_PILLOW = False
try:
    from PIL import Image, ImageTk
    HAS_PILLOW = True
except ImportError:
    print("Pillow not found. Install it with 'pip install pillow' for best BMP support.")

# --- CONFIGURATION ---
MAP_WIDTH = 32
MAP_HEIGHT = 24
TILE_SIZE = 32

TILE_ASSETS = [
    "__empty__",
    "./assets/tiles/brick.bmp",
    "./assets/tiles/brick_flipped.bmp",
    "./assets/tiles/spike_up.bmp",
    "./assets/tiles/spike_down.bmp",
    "./assets/tiles/spike_right.bmp",
    "./assets/tiles/spike_left.bmp"
]

FALLBACK_COLORS = ["white", "green", "blue", "gray", "yellow", "black"]

class TileMapEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Tilemap Editor")
        
        self.map_data = [[0 for _ in range(MAP_WIDTH)] for _ in range(MAP_HEIGHT)]
        
        self.tile_images = []
        self.icon_images = []
        self.current_tile_idx = 1
        self.spawn_location = None
        
        self.load_assets()
        self.setup_gui()
        self.draw_grid()

    def load_assets(self):
        for i, filename in enumerate(TILE_ASSETS):
            if i == 0:
                self.create_placeholder(i, is_empty=True)
                continue

            if HAS_PILLOW and os.path.exists(filename):
                try:
                    pil_img = Image.open(filename)
                    pil_img = pil_img.resize((TILE_SIZE, TILE_SIZE), Image.Resampling.NEAREST)
                    tk_img = ImageTk.PhotoImage(pil_img)
                    self.tile_images.append(tk_img)
                    self.icon_images.append(tk_img)
                except Exception as e:
                    print(f"Error loading {filename}: {e}")
                    self.create_placeholder(i)
            else:
                self.create_placeholder(i)

    def create_placeholder(self, index, is_empty=False):
        if is_empty:
            color = "white"
        else:
            color_idx = index % len(FALLBACK_COLORS)
            color = FALLBACK_COLORS[color_idx]
            
        self.tile_images.append(f"color:{color}")
        self.icon_images.append(f"color:{color}")

    def setup_gui(self):
        self.sidebar = tk.Frame(self.root, width=200, bg="#dddddd", padx=10, pady=10)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        
        self.main_area = tk.Frame(self.root)
        self.main_area.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        tk.Label(self.sidebar, text="Palette", bg="#dddddd", font=("Arial", 12, "bold")).pack(pady=(0, 10))

        self.btn_frame = tk.Frame(self.sidebar, bg="#dddddd")
        self.btn_frame.pack()

        btn_spawn = tk.Button(self.btn_frame, text="Spawn\n(-1)", bg="#ffcccc", width=6, height=2,
                              command=lambda: self.select_tile(-1))
        btn_spawn.grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="ew")

        row_offset = 1
        for i in range(len(TILE_ASSETS)):
            asset = self.icon_images[i]
            
            if i == 0:
                btn = tk.Button(self.btn_frame, text="Erase", bg="white", width=6, height=2,
                                command=lambda idx=i: self.select_tile(idx))
            elif isinstance(asset, str) and asset.startswith("color:"):
                color = asset.split(":")[1]
                btn = tk.Button(self.btn_frame, bg=color, width=4, height=2,
                                command=lambda idx=i: self.select_tile(idx))
            else:
                btn = tk.Button(self.btn_frame, image=asset,
                                command=lambda idx=i: self.select_tile(idx))
            
            btn.grid(row=row_offset + (i // 2), column=i % 2, padx=5, pady=5)

        tk.Label(self.sidebar, text="Selected:", bg="#dddddd").pack(pady=(20, 5))
        self.lbl_selected = tk.Label(self.sidebar, text=TILE_ASSETS[1], bg="#dddddd")
        self.lbl_selected.pack()

        tk.Button(self.sidebar, text="Load Map", command=self.load_map, bg="white").pack(side=tk.BOTTOM, pady=5)
        tk.Button(self.sidebar, text="Save Map", command=self.save_map, bg="white").pack(side=tk.BOTTOM, pady=5)

        canvas_w = MAP_WIDTH * TILE_SIZE
        canvas_h = MAP_HEIGHT * TILE_SIZE
        self.canvas = tk.Canvas(self.main_area, width=canvas_w, height=canvas_h, bg="white")
        self.canvas.pack(padx=10, pady=10)

        self.canvas.bind("<Button-1>", self.paint)
        self.canvas.bind("<B1-Motion>", self.paint)

    def select_tile(self, index):
        self.current_tile_idx = index
        if index == -1:
            self.lbl_selected.config(text="SPAWN POINT (-1)")
        elif index == 0:
            self.lbl_selected.config(text="Empty (0)")
        else:
            self.lbl_selected.config(text=f"{TILE_ASSETS[index]} ({index})")

    def paint(self, event):
        col = event.x // TILE_SIZE
        row = event.y // TILE_SIZE

        if 0 <= col < MAP_WIDTH and 0 <= row < MAP_HEIGHT:
            
            if self.current_tile_idx == -1:
                if self.spawn_location:
                    old_c, old_r = self.spawn_location
                    self.map_data[old_r][old_c] = 0
                    self.draw_single_tile(old_c, old_r, 0)
                
                self.spawn_location = (col, row)
            else:
                if self.spawn_location == (col, row):
                    self.spawn_location = None

            self.map_data[row][col] = self.current_tile_idx
            self.draw_single_tile(col, row, self.current_tile_idx)

    def draw_single_tile(self, col, row, tile_idx):
        x = col * TILE_SIZE
        y = row * TILE_SIZE
        tag = f"tile_{row}_{col}"
        
        self.canvas.delete(tag)

        if tile_idx == -1:
            self.canvas.create_rectangle(x, y, x+TILE_SIZE, y+TILE_SIZE, 
                                         fill="#ff4444", outline="black", tags=tag)
            self.canvas.create_text(x + TILE_SIZE/2, y + TILE_SIZE/2, 
                                    text="S", fill="white", font=("Arial", 14, "bold"), tags=tag)
            return

        asset = self.tile_images[tile_idx]

        if isinstance(asset, str) and asset.startswith("color:"):
            color = asset.split(":")[1]
            outline = "#e0e0e0" if tile_idx == 0 else "lightgray"
            self.canvas.create_rectangle(x, y, x+TILE_SIZE, y+TILE_SIZE, 
                                         fill=color, outline=outline, tags=tag)
        else:
            self.canvas.create_image(x, y, image=asset, anchor=tk.NW, tags=tag)

    def draw_grid(self):
        self.canvas.delete("all")
        for r in range(MAP_HEIGHT):
            for c in range(MAP_WIDTH):
                self.draw_single_tile(c, r, self.map_data[r][c])

    def save_map(self):
        if (not self.spawn_location):
            messagebox.showerror("Error", "Spawn point not set!")
            return
        
        file_path = filedialog.asksaveasfilename(defaultextension=".map",
                                                 filetypes=[("Map Files", "*.map")])
        if file_path:
            try:
                with open(file_path, "w") as f:
                    for row in self.map_data:
                        line = ",".join(map(str, row))
                        f.write(line + "\n")
                messagebox.showinfo("Success", "Map saved!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save: {e}")
    
    def load_map(self):
        file_path = filedialog.askopenfilename(filetypes=[("Map Files", "*.map")])
        if not file_path:
            return

        try:
            with open(file_path, "r") as f:
                new_map_data = []
                new_spawn = None
                
                rows = f.readlines()
                
                if len(rows) != MAP_HEIGHT:
                    messagebox.showerror("Error", f"Map height mismatch! Expected {MAP_HEIGHT}, got {len(rows)}")
                    return

                for r_idx, line in enumerate(rows):
                    values = line.strip().split(',')
                    
                    if len(values) != MAP_WIDTH:
                        messagebox.showerror("Error", f"Map width mismatch on row {r_idx}! Expected {MAP_WIDTH}, got {len(values)}")
                        return
                    
                    int_row = []
                    for c_idx, val in enumerate(values):
                        tile_id = int(val)
                        int_row.append(tile_id)
                        
                        if tile_id == -1:
                            new_spawn = (c_idx, r_idx)
                    
                    new_map_data.append(int_row)

                self.map_data = new_map_data
                self.spawn_location = new_spawn
                self.draw_grid()
                messagebox.showinfo("Success", "Map loaded successfully!")

        except ValueError:
            messagebox.showerror("Error", "File contains non-integer values.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load map: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    root.minsize(800, 600)
    app = TileMapEditor(root)
    root.mainloop()