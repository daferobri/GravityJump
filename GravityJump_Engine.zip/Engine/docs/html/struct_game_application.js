var struct_game_application =
[
    [ "this", "struct_game_application.html#a5d21a0eb3f441577cae61fdb3dcf943f", null ],
    [ "~this", "struct_game_application.html#a049bc8c1a681a9380aa85f2ca26c6034", null ],
    [ "AdvanceFrame", "struct_game_application.html#aada8f3529b125275b3ef1f27c2288356", null ],
    [ "Input", "struct_game_application.html#a587f67ea3b8d8dd4950163608c9189bb", null ],
    [ "Render", "struct_game_application.html#abaa232c34522e02e667937bcc88fd16a", null ],
    [ "RunLoop", "struct_game_application.html#a6a248734231421a03d6a24b647b8c5b9", null ],
    [ "Update", "struct_game_application.html#aa41e32bb8cc5e4df0639a34abe397c9c", null ]
];