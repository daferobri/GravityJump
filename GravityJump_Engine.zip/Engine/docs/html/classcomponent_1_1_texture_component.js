var classcomponent_1_1_texture_component =
[
    [ "this", "classcomponent_1_1_texture_component.html#afe9a4c8a60fd79d98166dc419cc2bac6", null ],
    [ "mTexture", "classcomponent_1_1_texture_component.html#a136fd92da2c1d8d6b556bdd40f3215d5", null ]
];