var structtree_1_1_tree_node =
[
    [ "this", "structtree_1_1_tree_node.html#a69d329018177be2872e8517be5fdb95b", null ],
    [ "AddChild", "structtree_1_1_tree_node.html#af3324868e100322f9aac85200dd2548b", null ],
    [ "mChildren", "structtree_1_1_tree_node.html#a61aaf83a702c0f006e9df7c2d8b6b2c5", null ],
    [ "mGo", "structtree_1_1_tree_node.html#a0a0dc022d0457cd0228de0ec70016fca", null ],
    [ "mLevel", "structtree_1_1_tree_node.html#af5e534794ac027506aca7bf0abbfa7e1", null ],
    [ "mNodeID", "structtree_1_1_tree_node.html#ac9109ae0478f992187b085a83fbf7533", null ],
    [ "mParentID", "structtree_1_1_tree_node.html#a6ad40d882fc7ca0b53e5fbb35d56e3a1", null ]
];