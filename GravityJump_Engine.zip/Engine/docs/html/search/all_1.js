var searchData=
[
  ['checkcollision_0',['CheckCollision',['../classscript_1_1_player_script.html#a550c65ab147596aca5c681adb02b8df0',1,'script::PlayerScript']]],
  ['collectcoin_1',['CollectCoin',['../classscene_1_1_scene.html#adc3adf7ca8b467529c00bdb7d35be062',1,'scene::Scene']]]
];
