var searchData=
[
  ['resourcemanager_0',['ResourceManager',['../structresourcemanager_1_1_resource_manager.html',1,'resourcemanager']]]
];
