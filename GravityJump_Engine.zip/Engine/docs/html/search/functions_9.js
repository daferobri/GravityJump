var searchData=
[
  ['setrenderer_0',['SetRenderer',['../structresourcemanager_1_1_resource_manager.html#a75860ef826aa79a831307495a843f1b9',1,'resourcemanager::ResourceManager']]],
  ['setroot_1',['SetRoot',['../structtree_1_1_scene_tree.html#ac71a6ddfce74a1e7ce598337b990354c',1,'tree::SceneTree']]]
];
