var structresourcemanager_1_1_animation_data =
[
    [ "mFrameNumbers", "structresourcemanager_1_1_animation_data.html#a5fc08bcc4651e628687dfd27f66b2622", null ]
];