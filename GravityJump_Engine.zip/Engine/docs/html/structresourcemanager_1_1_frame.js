var structresourcemanager_1_1_frame =
[
    [ "mElapsedTime", "structresourcemanager_1_1_frame.html#a42a56db360fbc3a565ae40b7679f7ec9", null ]
];